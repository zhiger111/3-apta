# University Management System — EF Core Code-First

Аптаның 3-зертханалық жұмысына арналған ASP.NET Core Web API жобасы. Мақсаты — кафедралар мен оқытушылар моделін құрып, Entity Framework Core арқылы SQL Server схемасына айналдыру.

## Жобаны іске қосу

Талаптар: .NET 10 SDK, SQL Server (немесе Docker арқылы SQL Server) және EF CLI. Жобаны басынан жасағанда Terminal-да:

```bash
dotnet new webapi -n UniversityDbApp --framework net10.0
cd UniversityDbApp
dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 10.0.0
dotnet add package Microsoft.EntityFrameworkCore.Design --version 10.0.0
```

Бұл дайын репозиторийді ашсаңыз, `dotnet new` пен `dotnet add package` қайталаудың қажеті жоқ: тәуелділіктер `UniversityDbApp.csproj` файлында көрсетілген. Жоба бумасында Terminal ашып:

```bash
dotnet tool install --global dotnet-ef --version 10.0.14
dotnet restore
dotnet ef migrations add InitialDb
dotnet ef database update
dotnet run
```

Егер `dotnet-ef` бұрын орнатылған болса, install командасының орнына `dotnet tool update --global dotnet-ef --version 10.0.14` орындаңыз. PowerShell қолданғанда да осы командалар Package Manager Console емес, терминалға енгізіледі. Visual Studio-дағы **Package Manager Console** үшін пакеттерді орнату және миграцияның баламасы: `Install-Package Microsoft.EntityFrameworkCore.SqlServer -Version 10.0.0`, `Install-Package Microsoft.EntityFrameworkCore.Tools -Version 10.0.0`, `Add-Migration InitialDb`, `Update-Database`. Package Manager Console-да Default project ретінде `UniversityDbApp` таңдалады.

### SQL Server қосылымы

`appsettings.json` ішіндегі `ConnectionStrings:UniversityDatabase` мысал мәні `localhost:1433` мекенжайындағы SQL Server-ге SQL аутентификациясымен қосылады. Құпиясөзді өз ортаңызға сай ауыстырыңыз. Құпия деректі репозиторийге жібермеңіз: локалды тексеруде файлдағы мәнді өзгертіңіз немесе production үшін `ConnectionStrings__UniversityDatabase` environment variable пайдаланыңыз.

Mac-та LocalDB қолжетімсіз; SQL Server-ді Docker контейнерінде не қашықтағы серверде іске қосуға болады. Windows-та сервер инстансының атауын (мысалы, `localhost\\SQLEXPRESS`) және қолданылатын аутентификация түрін connection string-те көрсетіңіз. Сервер дайын болмай тұрып `database update` орындамаңыз.

### Нәтижені тексеру

- Қосымшаны іске қосқаннан кейін браузерде `/api/departments` және `/api/teachers` мекенжайларын ашыңыз. Endpoint-тер тек оқу үшін жасалған және SQL Server-ден JSON қайтарады.
- SSMS-та сол серверге қосылып, `Databases > UniversityManagementDb > Tables` тармағын ашыңыз. `dbo.Departments`, `dbo.Teachers` және `dbo.__EFMigrationsHistory` кестелері көрінуі керек.
- `dbo.Teachers` кестесінің **Design** терезесінде `DepartmentId` бағанына қарайтын FK-ді және **Keys**/Database Diagram арқылы қатынасты тексеріңіз.
- Есепке нақты ортадан алынған скриншоттарды енгізіңіз: (1) кестелер тізімі, (2) `Teachers.DepartmentId` сыртқы кілті, (3) екі API endpoint жауабы. Репозиторийге ойдан шығарылған скриншоттар қосылмаған.

## Модель шешімдері

- `Department` — бір кафедра; `Teachers` навигациялық жинағы оған тиесілі оқытушыларды көрсетеді.
- `Teacher.DepartmentId` — міндетті FK, ал `Department` — навигациялық қасиет. Fluent API `HasOne/WithMany/HasForeignKey` арқылы бір кафедраның бірнеше оқытушысы болатынын бекітеді. `Restrict` кафедрасы бар оқытушыларды кездейсоқ өшіруден қорғайды.
- Data Annotations мәтіннің міндеттілігін және ең үлкен ұзындығын көрсетеді; Fluent API кесте/индекс/қатынас конфигурациясын бір жерде жинайды. Кафедра коды мен email бірегей индекстер арқылы қорғалған.
- `HasData` бастапқы үш кафедра мен төрт оқытушыны миграцияға енгізеді. Seed деректері демонстрацияға арналған, нақты жеке деректерді қамтымайды.
- `AsNoTracking` GET сұрауларында өзгертілмейтін нәтижелерге EF change tracking шығынын қоспайды. `CancellationToken` сұрау тоқтаған кезде дерекқор операциясын тоқтатуға мүмкіндік береді.

## GitHub-қа жариялау

`bin/`, `obj/`, IDE файлдары `.gitignore` ішінде. Жариялар алдында connection string-тегі парольді тексеріп, жеке құпиялардың Git тарихына түспегеніне көз жеткізіңіз. Оқу жобасының кодын, есепті және қажет болса автор өзі түсірген экран суреттерін commit етіңіз.

## Құрылым

```text
UniversityDbApp/
├── Data/
│   ├── AppDbContext.cs
│   └── DesignTimeDbContextFactory.cs
├── Migrations/
│   ├── 20261112173616_InitialDb.cs
│   ├── 20261112173616_InitialDb.Designer.cs
│   └── AppDbContextModelSnapshot.cs
├── Models/
│   ├── Department.cs
│   └── Teacher.cs
├── Program.cs
├── appsettings.json
├── appsettings.Development.json
└── UniversityDbApp.csproj
```
