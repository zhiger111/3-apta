using System.ComponentModel.DataAnnotations;

namespace UniversityDbApp.Models;

public sealed class Teacher
{
    public int Id { get; set; }

    [Required, StringLength(80)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(160)]
    public string Email { get; set; } = string.Empty;

    [StringLength(100)]
    public string? AcademicTitle { get; set; }

    public int DepartmentId { get; set; }

    public Department Department { get; set; } = null!;
}
