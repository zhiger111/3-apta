using System.ComponentModel.DataAnnotations;

namespace UniversityDbApp.Models;

public sealed class Department
{
    public int Id { get; set; }

    [Required, StringLength(120)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(12)]
    public string Code { get; set; } = string.Empty;

    [StringLength(300)]
    public string? Description { get; set; }

    public ICollection<Teacher> Teachers { get; set; } = new List<Teacher>();
}
