using Microsoft.EntityFrameworkCore;
using UniversityDbApp.Data;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("UniversityDatabase")
    ?? throw new InvalidOperationException("Connection string 'UniversityDatabase' was not found.");

builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/departments", async (AppDbContext db, CancellationToken cancellationToken) =>
    Results.Ok(await db.Departments.AsNoTracking()
        .OrderBy(department => department.Name)
        .Select(department => new
        {
            department.Id,
            department.Name,
            department.Code,
            TeachersCount = department.Teachers.Count
        })
        .ToListAsync(cancellationToken)));

app.MapGet("/api/teachers", async (AppDbContext db, CancellationToken cancellationToken) =>
    Results.Ok(await db.Teachers.AsNoTracking()
        .OrderBy(teacher => teacher.LastName)
        .ThenBy(teacher => teacher.FirstName)
        .Select(teacher => new
        {
            teacher.Id,
            teacher.FirstName,
            teacher.LastName,
            teacher.Email,
            Department = teacher.Department.Name
        })
        .ToListAsync(cancellationToken)));

app.Run();
