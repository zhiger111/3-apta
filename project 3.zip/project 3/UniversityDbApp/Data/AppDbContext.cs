using Microsoft.EntityFrameworkCore;
using UniversityDbApp.Models;

namespace UniversityDbApp.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Teacher> Teachers => Set<Teacher>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Department>(entity =>
        {
            entity.ToTable("Departments");
            entity.HasKey(department => department.Id);
            entity.HasIndex(department => department.Code).IsUnique();
            entity.Property(department => department.Name).IsRequired().HasMaxLength(120);
            entity.Property(department => department.Code).IsRequired().HasMaxLength(12);
            entity.Property(department => department.Description).HasMaxLength(300);
        });

        modelBuilder.Entity<Teacher>(entity =>
        {
            entity.ToTable("Teachers");
            entity.HasKey(teacher => teacher.Id);
            entity.HasIndex(teacher => teacher.Email).IsUnique();
            entity.Property(teacher => teacher.FirstName).IsRequired().HasMaxLength(80);
            entity.Property(teacher => teacher.LastName).IsRequired().HasMaxLength(80);
            entity.Property(teacher => teacher.Email).IsRequired().HasMaxLength(160);
            entity.Property(teacher => teacher.AcademicTitle).HasMaxLength(100);

            entity.HasOne(teacher => teacher.Department)
                .WithMany(department => department.Teachers)
                .HasForeignKey(teacher => teacher.DepartmentId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Department>().HasData(
            new Department { Id = 1, Name = "Computer Science", Code = "CS", Description = "Software engineering and computing" },
            new Department { Id = 2, Name = "Applied Mathematics", Code = "MATH", Description = "Mathematics, statistics and modelling" },
            new Department { Id = 3, Name = "Information Systems", Code = "IS", Description = "Digital systems and data management" });

        modelBuilder.Entity<Teacher>().HasData(
            new Teacher { Id = 1, FirstName = "Aigerim", LastName = "Saparova", Email = "a.saparova@university.example", AcademicTitle = "Senior Lecturer", DepartmentId = 1 },
            new Teacher { Id = 2, FirstName = "Dias", LastName = "Nurlanov", Email = "d.nurlanov@university.example", AcademicTitle = "Associate Professor", DepartmentId = 1 },
            new Teacher { Id = 3, FirstName = "Mira", LastName = "Bekova", Email = "m.bekova@university.example", AcademicTitle = "Lecturer", DepartmentId = 2 },
            new Teacher { Id = 4, FirstName = "Arman", LastName = "Tulegen", Email = "a.tulegen@university.example", AcademicTitle = "Assistant Professor", DepartmentId = 3 });
    }
}
