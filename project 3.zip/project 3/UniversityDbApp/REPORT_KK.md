# ЗЕРТХАНАЛЫҚ ЖҰМЫС №3

## Титулдық бет

**Оқу орны:** ____________________________________  
**Факультет:** ____________________________________  
**Пәні:** _________________________________________  

**Тақырыбы:** EF Core жүйесін орнату және дерекқор құрылымын Code-First арқылы құру  
**Жоба атауы:** UniversityDbApp  

**Орындаған:** __________________, топ __________  
**Қабылдаған:** __________________________________  

**Қала, 2026**

---

## Жұмыстың мақсаты

Entity Framework Core құралдарын ASP.NET Core жобасына қосу, пәндік аймақтың екі моделін анықтау, олардың One-to-Many байланысын сыртқы кілтпен орнату және Code-First миграциялары арқылы SQL Server дерекқор схемасын басқару.

## Теориялық бөлім

Code-First тәсілінде деректер құрылымы алдымен C# модельдері мен олардың конфигурациясы арқылы сипатталады. EF Core осы модельдерден миграция жасайды. Миграция — модель өзгерісін SQL схемасына қолдануға арналған нұсқаланатын C# сипаттамасы; ол кесте, баған, индекс, шектеу және бастапқы деректер өзгерістерін қамтиды. `Add-Migration` миграция файлын жасайды, ал `Update-Database` оны қосылым жолында көрсетілген SQL Server-ге қолданады. Қолданылған миграциялар `__EFMigrationsHistory` кестесінде тіркеледі.

`DbContext` қолданба мен дерекқор арасындағы жұмыс бірлігін атқарады. Оның `DbSet<T>` қасиеттері модельдер жиынын ұсынады, модель конфигурациясы кілттер мен қатынастарды анықтайды, ал контекст сұрауларды SQL-ге айналдырып, өзгерістерді сақтайды. Бұл жобада контекст dependency injection контейнеріне `AddDbContext` арқылы тіркеледі.

Қатынас бір кафедрадан көптеген оқытушыға бағытталған. `Teachers.DepartmentId` міндетті FK болғандықтан, әр оқытушы дәл бір кафедраға тиесілі; кафедраның `Teachers` жинағы кері навигация береді. `DeleteBehavior.Restrict` оқытушылары бар кафедраны өшіруді шектейді, сондықтан деректер тұтастығы сақталады.

## Практикалық бөлім

### Жобаны және тәуелділіктерді дайындау

Жоба .NET 10 ASP.NET Core Web API үлгісінде құрылды. `UniversityDbApp.csproj` ішінде SQL Server провайдері және EF құралдарына қажет Design пакеті көрсетілген. Терминалда жоба бумасына өтіп:

```bash
dotnet restore
dotnet tool install --global dotnet-ef --version 10.0.14
```

Егер EF CLI орнатылған болса, оны `dotnet tool update --global dotnet-ef --version 10.0.14` арқылы жаңарту жеткілікті. Бұл командалар VS Code/операциялық жүйе терминалына енгізіледі. Visual Studio Package Manager Console нұсқасы `README.md` файлында берілген.

### Байланыс жолы мен контекст

`appsettings.json` файлындағы `UniversityDatabase` жолын жергілікті SQL Server баптауларына сәйкестендіру қажет. Үлгіде SQL Server TCP `localhost,1433` адресінде тыңдайды деп есептелген. Үлгі парольді нақты ортадағы қауіпсіз парольге ауыстырыңыз; жария репозиторийге нақты құпияны енгізбеңіз.

`Program.cs` конфигурациядан аталған connection string-ті алып, `UseSqlServer` арқылы `AppDbContext` қызметін тіркейді. Қосылым жолы жоқ болса, қолданба түсінікті қате береді. `DesignTimeDbContextFactory` EF CLI-ге серверді іске қоспай-ақ миграция моделін құруға мүмкіндік береді.

### Жобаның құрылымы

```text
UniversityDbApp/
├── Data/AppDbContext.cs
├── Data/DesignTimeDbContextFactory.cs
├── Migrations/
│   ├── 20261112173616_InitialDb.cs
│   ├── 20261112173616_InitialDb.Designer.cs
│   └── AppDbContextModelSnapshot.cs
├── Models/Department.cs
├── Models/Teacher.cs
├── Program.cs
├── appsettings.json
├── appsettings.Development.json
├── UniversityDbApp.csproj
├── README.md
└── REPORT_KK.md
```

`Migrations/` бумасында `InitialDb` миграциясы, оның дизайнер сипаттамасы және `AppDbContextModelSnapshot` бар. Snapshot EF Core-ға келесі миграция кезінде модельдің алдыңғы күйін салыстыруға көмектеседі.

### Бағдарламалық код

Жобаның толық бастапқы коды осы есеппен бірге берілген файлдарда орналасқан: `Models/Department.cs`, `Models/Teacher.cs`, `Data/AppDbContext.cs`, `Data/DesignTimeDbContextFactory.cs`, `Program.cs`, `appsettings.json` және `UniversityDbApp.csproj`.

Мысалы, байланыстың мәні Fluent API-де былай беріледі:

```csharp
entity.HasOne(teacher => teacher.Department)
    .WithMany(department => department.Teachers)
    .HasForeignKey(teacher => teacher.DepartmentId)
    .IsRequired()
    .OnDelete(DeleteBehavior.Restrict);
```

Бұл конфигурация навигациялық қасиеттерді, FK бағанын, міндеттілікті және өшіру саясатын бірге анықтайды. Модельдердегі Data Annotations өрістердің талап етілуін және ең үлкен ұзындығын құжаттап, тексеруге көмектеседі. Кафедра коды мен оқытушы email-ына бірегей индекс қайталанатын сәйкестендіргіштерге жол бермейді.

Жоба демонстрация үшін `/api/departments` және `/api/teachers` оқуға арналған endpoint-терін ұсынады. Сұраулар `AsNoTracking` қолданады, себебі қайтарылған нысандар өзгертілмейді; асинхронды сұраулар `CancellationToken` қабылдайды.

### Миграцияларды орындау

SQL Server серверін алдын ала іске қосып, `appsettings.json` жолының дұрыстығын тексерген соң Terminal-да `UniversityDbApp` жобасының түбірінде:

```bash
dotnet ef migrations add InitialDb
dotnet ef database update
```

Бірінші пәрмен `Migrations` каталогында схема мен бастапқы деректерді сипаттайтын миграция жасайды. Екінші пәрмен миграцияны қосылымдағы дерекқорға қолданады. Visual Studio Package Manager Console қолданылса, Default project ретінде `UniversityDbApp` таңдап, мына пәрмендерді енгізіңіз:

```powershell
Add-Migration InitialDb
Update-Database
```

Жоба құрамында `InitialDb` миграциясы бар: EF CLI көмегімен миграция файлдары сәтті жасалды. Код `dotnet build --no-restore` командасымен тексеріліп, 0 қате тіркелді; желі шектеуіне байланысты NuGet осалдықтар дерекқорына қосыла алмағаны туралы ескерту шықты. SQL Server инстансында `Update-Database` немесе `database update` пәрмені орындалған жоқ, сондықтан нақты дерекқор жасалды деп расталмайды. Жұмыс компьютерінде жоғарыдағы жаңарту қадамын орындап, сәтті нәтиже мен SSMS скриншоттарын есептің соңына тіркеңіз.

### Дерекқор құрылымының түсіндірмесі

Миграция екі негізгі кесте жасайды:

| Кесте | Негізгі өрістер | Шектеулер |
|---|---|---|
| `Departments` | `Id` (PK), `Name`, `Code`, `Description` | `Code` бірегей, `Name` және `Code` міндетті |
| `Teachers` | `Id` (PK), `FirstName`, `LastName`, `Email`, `AcademicTitle`, `DepartmentId` (FK) | email бірегей; `DepartmentId` міндетті FK |

`Teachers.DepartmentId` → `Departments.Id` байланысы One-to-Many қатынасын іске асырады. `HasData` үш мысал кафедраны және төрт оқытушыны миграцияға қосады. Сыртқы кілт кафедрасы жоқ оқытушыны қосуды болдырмайды.

### Миграция нәтижесі және тексеру

SSMS-ты ашып, connection string-тегі SQL Server инстансына қосылыңыз. Object Explorer ішінде `Databases > UniversityManagementDb > Tables` тармағын кеңейтіңіз. `dbo.Departments`, `dbo.Teachers`, `dbo.__EFMigrationsHistory` кестелерін тексеріңіз. `dbo.Teachers` кестесінің **Design** көрінісінен `DepartmentId` бағанын табыңыз. **Keys** немесе Database Diagram арқылы бұл бағанның `Departments.Id` кілтіне сілтейтінін растаңыз.

Қосымшаны `dotnet run` арқылы іске қосып, `/api/departments` және `/api/teachers` мекенжайларындағы JSON жауаптарын тексеріңіз. Есепке мына нақты скриншоттарды кейін тіркеңіз:

1. SSMS Object Explorer-де дерекқор кестелері;
2. `Teachers.DepartmentId` сыртқы кілті;
3. `/api/departments` және `/api/teachers` жауаптарының көрінісі;
4. Қажет болса, `dotnet ef database update` сәтті аяқталған терминал нәтижесі.

## Қорытынды

Жұмыста `Department` және `Teacher` модельдері құрылып, олардың міндетті One-to-Many байланысы FK арқылы сипатталды. EF Core конфигурациясында ұзындық шектеулері, бірегей индекстер, өшіру саясаты және демонстрациялық бастапқы деректер анықталды. Миграция механизмі модель өзгерістерін SQL Server схемасына нұсқаланған түрде жеткізеді; `DbContext` осы модельдермен сұрау орындаудың бірыңғай нүктесі болады. Дерекқорға нақты тексеру `InitialDb` миграциясын жергілікті SQL Server-де орындаған соң жасалып, скриншоттармен толықтырылады.
